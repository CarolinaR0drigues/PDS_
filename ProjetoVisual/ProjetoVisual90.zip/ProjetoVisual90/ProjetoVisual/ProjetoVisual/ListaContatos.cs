﻿namespace ProjetoVisual
{
    internal class ListaContatos
    {
    }
}