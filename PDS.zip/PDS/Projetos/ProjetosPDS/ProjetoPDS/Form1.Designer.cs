﻿namespace ProjetoPDS
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btCadastro = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btListContatos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btCadastro
            // 
            this.btCadastro.BackColor = System.Drawing.Color.Transparent;
            this.btCadastro.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btCadastro.Font = new System.Drawing.Font("Microsoft Himalaya", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCadastro.Location = new System.Drawing.Point(39, 146);
            this.btCadastro.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btCadastro.Name = "btCadastro";
            this.btCadastro.Size = new System.Drawing.Size(468, 49);
            this.btCadastro.TabIndex = 0;
            this.btCadastro.Text = "Cadastrar Contato";
            this.btCadastro.UseVisualStyleBackColor = false;
            this.btCadastro.Click += new System.EventHandler(this.btCadastro_Click);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Himalaya", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(541, 68);
            this.label1.TabIndex = 1;
            this.label1.Text = "MENU";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btListContatos
            // 
            this.btListContatos.BackColor = System.Drawing.Color.Transparent;
            this.btListContatos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btListContatos.Font = new System.Drawing.Font("Microsoft Himalaya", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btListContatos.Location = new System.Drawing.Point(39, 217);
            this.btListContatos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btListContatos.Name = "btListContatos";
            this.btListContatos.Size = new System.Drawing.Size(468, 49);
            this.btListContatos.TabIndex = 2;
            this.btListContatos.Text = "Listar Contatos";
            this.btListContatos.UseVisualStyleBackColor = false;
            this.btListContatos.Click += new System.EventHandler(this.btListContatos_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(541, 309);
            this.Controls.Add(this.btListContatos);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btCadastro);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MENU";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btCadastro;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btListContatos;
    }
}

