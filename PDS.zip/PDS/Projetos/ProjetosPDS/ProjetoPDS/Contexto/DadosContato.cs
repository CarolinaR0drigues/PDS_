﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjetoPDS.RegrasDeNegocio;
namespace ProjetoPDS.Contexto
{
    internal class DadosContato
    {
        public static List<Cadastramento> lista = new List<Cadastramento>();
    }
}